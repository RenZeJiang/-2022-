package com.example.renzejiangcode;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.renzejiangcode.api.ApiDatas;
import com.example.renzejiangcode.entity.tianqi.Root;
import com.example.renzejiangcode.entity.xingzuo.Today;
import com.example.renzejiangcode.entity.xingzuo.Week;
import com.example.renzejiangcode.tool.Common;
import com.example.renzejiangcode.tool.ServiceFactory;

public class Xingzuo extends AppCompatActivity {
    private EditText xz_name;
    private EditText xz_type;
    private Button xz_btn_query;
    private TextView cx_Con;
    private TextView xz_desc;

    //网络请求工具
    private ServiceFactory mService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xingzuo);

        //初始化控件
        initViews();

        //实例化网络请求工具
        mService = ServiceFactory.getInstance();
    }

    /**
     * 该方法用于处理视图的初始化
     */
    private void initViews() {
        //findviewbyid
        xz_name = findViewById(R.id.xz_name);
        xz_type = findViewById(R.id.xz_type);
        xz_btn_query = findViewById(R.id.xz_btn_query);
        cx_Con = findViewById(R.id.cx_Con);
        xz_desc = findViewById(R.id.xz_desc);

        //查询按钮的监听事件
        xz_btn_query.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                queryPolicy(); //查询星座运势
            }
        });
    }

    /**
     * 该方法用于查询星座运势
     */
    private void queryPolicy() {
        String name = xz_name.getText().toString();
        String type = xz_type.getText().toString();
        //网络请求星座数据
        if (type.equals("today")){
            ApiDatas api = mService.createService(ApiDatas.class, Common.XingZuo_URL);
            Call<Today> call = api.getTodayYunShi(name,type,Common.XingZuo_KEY);
            call.enqueue(new Callback<Today>() {
                @Override
                public void onResponse(Call<Today> call, Response<Today> response) {
                    //星座请求成功，将数据设置到界面上
                    queryNameSuccess(response.body());
                }

                @Override
                public void onFailure(Call<Today> call, Throwable t) {
                    System.out.println("输出失败！");
                }
            });
        }

        if (type.equals("week")){
            ApiDatas api = mService.createService(ApiDatas.class, Common.XingZuo_URL);
            Call<Week> call1 = api.getWeekYunShi(name,type,Common.XingZuo_KEY);
            call1.enqueue(new Callback<Week>() {
                @Override
                public void onResponse(Call<Week> call, Response<Week> response) {
                    //星座请求成功，将数据设置到界面上
                    queryWeekSuccess(response.body());
                }

                @Override
                public void onFailure(Call<Week> call, Throwable t) {
                    System.out.println("输出失败！");
                }
            });
        }
    }

    private void queryNameSuccess(Today body) {
        if (body.getError_code() != 0) {
            //没有获取到数据
            return;
        }
        xz_desc.setText("星座名称："+body.getName()
                +"\n日期"+body.getDatetime()
                +"\n综合指数："+body.getAll()
                +"\n幸运颜色："+body.getColor()
                +"\n健康指数："+body.getHealth()
                +"\n爱情指数"+body.getLove()
                +"\n财运指数："+body.getMoney()
                +"\n幸运数字："+body.getNumber()
                +"\n速配星座："+body.getQFriend()
                +"\n今日概述"+body.getSummary()
                +"\n工作指数"+body.getWork()

        );
    }

    private void queryWeekSuccess(Week body) {
        if (body.getError_code() != 0) {
            //没有获取到数据
            return;
        }
        xz_desc.setText("星座名称:"+body.getName()
                        +"\n日期:"+body.getDate()
                        +"\n周次:"+body.getWeekth()
                        +"\n健康方面:"+body.getHealth()
                        +"\n感情方面:"+body.getLove()
                        +"\n财运:"+body.getMoney()
                        +"\n工作方面:"+body.getWork()
        );
    }
}
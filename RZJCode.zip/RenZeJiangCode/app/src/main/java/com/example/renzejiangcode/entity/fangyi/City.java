package com.example.renzejiangcode.entity.fangyi;

/**
 * Author: RenZeJiang
 * Date: 2022/6/12  10:24
 * Email: 78971285@qq.com
 * Description :
 */

public class City {
	private String city_id;
	private String city;

	public String getCity_id() {
		return city_id;
	}

	public void setCity_id(String city_id) {
		this.city_id = city_id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
}


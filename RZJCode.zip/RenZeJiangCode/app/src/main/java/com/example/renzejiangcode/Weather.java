package com.example.renzejiangcode;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.renzejiangcode.api.ApiDatas;
import com.example.renzejiangcode.entity.tianqi.Root;
import com.example.renzejiangcode.tool.Common;
import com.example.renzejiangcode.tool.ServiceFactory;

public class Weather extends AppCompatActivity {
    private EditText tq_city;
    private Button tq_btn_query;
    private TextView cx_City;
    private TextView tq_desc;

    //网络请求工具
    private ServiceFactory mService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
        //初始化控件
        initViews();

        //实例化网络请求工具
        mService = ServiceFactory.getInstance();
    }

    /**
     * 该方法用于处理视图的初始化
     */
    private void initViews() {
        //findviewbyid
        tq_city = findViewById(R.id.tq_city);
        tq_btn_query = findViewById(R.id.tq_btn_query);
        cx_City = findViewById(R.id.cx_City);
        tq_desc = findViewById(R.id.tq_desc);

        //查询按钮的监听事件
        tq_btn_query.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                queryPolicy(); //查询天气
            }
        });
    }

    /**
     * 该方法用于查询天气
     */
    private void queryPolicy() {
        String abcity = tq_city.getText().toString();
        //网络请求 天气数据
        ApiDatas api = mService.createService(ApiDatas.class, Common.WEATHER_URL);
        Call<Root> call = api.getWeather(abcity,Common.WEATHER_KEY);
        call.enqueue(new Callback<Root>() {
            @Override
            public void onResponse(Call<Root> call, Response<Root> response) {
                //天气信息请求成功，将数据设置到界面上
                queryWeatherSuccess(response.body());
            }

            @Override
            public void onFailure(Call<Root> call, Throwable t) {

            }
        });
    }

    private void queryWeatherSuccess(Root body) {
        if (body.getError_code() != 0) {
            //没有获取到数据
            return;
        }
        tq_desc.setText(body.getResult().getCity()
                +"\n温度："+body.getResult().getRealtime().getTemperature()+"℃"
                +"\n湿度："+body.getResult().getRealtime().getHumidity()+"hPa"
                +"\n天气情况："+body.getResult().getRealtime().getInfo()
                +"\n风向："+body.getResult().getRealtime().getDirect()
                +"\n风力："+body.getResult().getRealtime().getHumidity()+"m/s"
                +"\n空气质量指数："+body.getResult().getRealtime().getAqi()+"J/kg℃");
    }
}
package com.example.renzejiangcode.api;

import com.example.renzejiangcode.entity.fangyi.Citys;
import com.example.renzejiangcode.entity.fangyi.PolicyResult;
import com.example.renzejiangcode.entity.tianqi.Root;
import com.example.renzejiangcode.entity.xingzuo.Today;
import com.example.renzejiangcode.entity.xingzuo.Week;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Author: RenZeJiang
 * Date: 2022/6/11  23:41
 * Email: 78971285@qq.com
 * Description :
 */

public interface ApiDatas {
    /**
     * 请求城市列表的接口
     * @param key
     * @return
     */
    @GET("citys")
    Call<Citys> getCityList(@Query("key") String key);

    /**
     * 请求防疫政策的接口
     * @param key
     * @param from
     * @param to
     * @return
     */
    @GET("query")
    Call<PolicyResult> getPolicy(@Query("key") String key, @Query("from") int from, @Query("to") int to);
    /**
     * 请求天气的接口
     * @param key
     * @param city
     * @return
     */
    @GET("query")
    Call<Root> getWeather(@Query("city") String city,@Query("key") String key);

    /**
     * 请求星座运势的接口
     * @param consName
     * @param type
     * @param key
     * @return
     */
    @GET("getAll")
    Call<Today> getTodayYunShi(@Query("consName") String consName, @Query("type") String type, @Query("key") String key);

    /**
     * 请求星座运势的接口
     * @param consName
     * @param type
     * @param key
     * @return
     */
    @GET("getAll")
    Call<Week> getWeekYunShi(@Query("consName") String consName, @Query("type") String type, @Query("key") String key);
}

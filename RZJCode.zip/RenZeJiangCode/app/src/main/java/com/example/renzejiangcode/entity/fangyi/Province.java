package com.example.renzejiangcode.entity.fangyi;

import com.example.renzejiangcode.entity.fangyi.City;

import java.util.List;

/**
 * Author: RenZeJiang
 * Date: 2022/6/12  10:21
 * Email: 78971285@qq.com
 * Description :
 */

public class Province {
    private String province_id;
    private String province;
    private List<City> citys;

    public String getProvince_id() {
        return province_id;
    }

    public void setProvince_id(String province_id) {
        this.province_id = province_id;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public List<City> getCitys() {
        return citys;
    }

    public void setCitys(List<City> citys) {
        this.citys = citys;
    }
}
package com.example.renzejiangcode.entity.tianqi;

/**
 * Author: RenZeJiang
 * Date: 2022/6/14  21:40
 * Email: 78971285@qq.com
 * Description :
 */

public class Result {
	private String city;

	private Weather realtime;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Weather getRealtime() {
		return realtime;
	}

	public void setRealtime(Weather realtime) {
		this.realtime = realtime;
	}
}

package com.example.renzejiangcode.entity.fangyi;

import com.example.renzejiangcode.entity.fangyi.PolicyDetail;

/**
 * Author: RenZeJiang
 * Date: 2022/6/12  10:48
 * Email: 78971285@qq.com
 * Description :
 */

public class PolicyInfo {
	private PolicyDetail from_info;
	private PolicyDetail to_info;
	private String tc_tag;
	private String fc_tag;
	private String t_tag;
	private String f_tag;
	public PolicyDetail getFrom_info() {
		return from_info;
	}

	public void setFrom_info(PolicyDetail from_info) {
		this.from_info = from_info;
	}

	public PolicyDetail getTo_info() {
		return to_info;
	}

	public void setTo_info(PolicyDetail to_info) {
		this.to_info = to_info;
	}

	public String getTc_tag() {
		return tc_tag;
	}

	public void setTc_tag(String tc_tag) {
		this.tc_tag = tc_tag;
	}

	public String getFc_tag() {
		return fc_tag;
	}

	public void setFc_tag(String fc_tag) {
		this.fc_tag = fc_tag;
	}

	public String getT_tag() {
		return t_tag;
	}

	public void setT_tag(String t_tag) {
		this.t_tag = t_tag;
	}

	public String getF_tag() {
		return f_tag;
	}

	public void setF_tag(String f_tag) {
		this.f_tag = f_tag;
	}
}

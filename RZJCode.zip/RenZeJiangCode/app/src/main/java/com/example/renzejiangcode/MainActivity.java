package com.example.renzejiangcode;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.renzejiangcode.api.ApiDatas;
import com.example.renzejiangcode.entity.fangyi.City;
import com.example.renzejiangcode.entity.fangyi.Citys;
import com.example.renzejiangcode.entity.fangyi.Province;
import com.example.renzejiangcode.entity.fangyi.PolicyResult;
import com.example.renzejiangcode.tool.Common;
import com.example.renzejiangcode.tool.ServiceFactory;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Spinner mFromSpProvince;
    private Spinner mFromSpCity;
    private Spinner mToSpProvince;
    private Spinner mToSpCity;
    private Button mBtnQuery;
    //出发城市
    private TextView mTvFrom;
    //出发城市的出城防疫政策
    private TextView mTvFromDesc;
    //到达城市
    private TextView mTvTo;
    private TextView mTvToDesc;

    private View mViewLine;

    //出发城市的id
    private String mFromCityName;
    private String mFromCityId;
    //到达城市的id
    private String mToCityName;
    private String mToCityId;

    //网络请求工具
    private ServiceFactory mService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //初始化控件
        initViews();

        //实例化网络请求工具
        mService = ServiceFactory.getInstance();

        //请求可供选择的城市列表信息，并将请求到的结果设置给对应控件
        loadCityList();
    }

    /**
     * 加载城市列表信息
     */
    private void loadCityList() {
        //发起网络请求
        ApiDatas apiDatas = mService.createService(ApiDatas.class, Common.FANGYI_URL);
        Call<Citys> call = apiDatas.getCityList(Common.FANGYI_KEY);//构建了请求
        //发起执行请求
        call.enqueue(new Callback<Citys>() {
            @Override
            public void onResponse(retrofit2.Call<Citys> call, Response<Citys> response) {
                //网络请求成功的回调
                //把请求到的数据设置给界面中的控件
                queryCitysSuccess(response.body());
            }

            @Override
            public void onFailure(retrofit2.Call<Citys> call, Throwable t) {
                //网络请求失败的回调
            }
        });
    }

    public void queryCitysSuccess(Citys citys) {
        if (citys.getError_code() != 0) {
            //没有获取到数据
            return;
        }
        //设置出发城市的省份 适配器
        setProvincesData(mFromSpProvince, citys.getResult());
        //设置出发城市的城市 适配器
        setCityData(mFromSpCity, citys.getResult().get(0).getCitys());

        //设置到达城市的身份 适配器
        setProvincesData(mToSpProvince, citys.getResult());
        //设置到达城市的城市 适配器
        setCityData(mToSpCity, citys.getResult().get(0).getCitys());
    }

    /**
     * 设置两个级联菜单的数据
     */
    private void setProvincesData(final Spinner spinner, final List<Province> prolist) {
        if (prolist == null) {
            return;
        }
        String[] proArray = new String[prolist.size()];
        for (int i = 0; i < prolist.size(); i++) {
            proArray[i] = prolist.get(i).getProvince();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.item_spinner_dropdown, proArray);
        spinner.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (spinner.getId()) {
                    case R.id.sp_province:
                        setCityData(mFromSpCity, prolist.get(position).getCitys());
                        break;
                    case R.id.sp_to_province:
                        setCityData(mToSpCity, prolist.get(position).getCitys());
                        break;
                    default:
                        break;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    /**
     * 选择了某个省份以后，设置对应的省份的包含城市的列表信息
     *
     * @param citys 某个省所包含的城市的信息
     */
    private void setCityData(final Spinner spinner, final List<City> citys) {
        if (citys == null) {
            return;
        }
        String[] cityArray = new String[citys.size()];
        for (int i = 0; i < citys.size(); i++) {
            cityArray[i] = citys.get(i).getCity();
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_spinner_dropdown, cityArray);
        spinner.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (spinner.getId()) {
                    case R.id.sp_city:
                        mFromCityName = citys.get(position).getCity();
                        mFromCityId = citys.get(position).getCity_id();
                        break;
                    case R.id.sp_to_city:
                        mToCityName = citys.get(position).getCity();
                        mToCityId = citys.get(position).getCity_id();
                        break;
                    default:
                        break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    /**
     * 该方法用于处理视图的初始化
     */
    private void initViews() {
        //findviewbyid
        mFromSpProvince = findViewById(R.id.sp_province);
        mFromSpCity = findViewById(R.id.sp_city);
        mToSpProvince = findViewById(R.id.sp_to_province);
        mToSpCity = findViewById(R.id.sp_to_city);
        mBtnQuery = findViewById(R.id.btn_query);
        mTvFrom = findViewById(R.id.tv_from);
        mTvFromDesc = findViewById(R.id.tv_from_desc);
        mTvTo = findViewById(R.id.tv_to);
        mTvToDesc = findViewById(R.id.tv_to_desc);
        mViewLine = findViewById(R.id.view_line);

        //查询按钮的监听事件
        mBtnQuery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                queryPolicy();//查询防疫政策
            }
        });
    }

    /**
     * 该方法用于查询防疫政策
     */
    private void queryPolicy() {
        //网络请求 防疫政策数据
        ApiDatas api = mService.createService(ApiDatas.class, Common.FANGYI_URL);
        //from:出发城市
        //to:到达城市
        int fromId = Integer.parseInt(mFromCityId);
        int toId = Integer.parseInt(mToCityId);
        Call<PolicyResult> call = api.getPolicy(Common.FANGYI_KEY,fromId,toId);
        call.enqueue(new Callback<PolicyResult>() {
            @Override
            public void onResponse(Call<PolicyResult> call, Response<PolicyResult> response) {
                //防疫政策请求成功，将数据设置到界面上
                queryPolicySuccess(response.body());
            }

            @Override
            public void onFailure(Call<PolicyResult> call, Throwable t) {

            }
        });
    }

    public void queryPolicySuccess(PolicyResult result) {
        if (result.getError_code() != 0) {
            return;
        }
        mTvFrom.setText(mFromCityName);
        mTvFromDesc.setText(result.getResult().getFrom_info().getOut_desc());

        mViewLine.setVisibility(View.VISIBLE);

        mTvTo.setText(mToCityName);
        mTvToDesc.setText(result.getResult().getTo_info().getLow_in_desc());
    }
}
package com.example.renzejiangcode.tool;

/**
 * Author: RenZeJiang
 * Date: 2022/6/11  20:54
 * Email: 78971285@qq.com
 * Description :接口配置
 */

public class Common {
    //2022出行防疫政策接口的KEY值
    public static String FANGYI_KEY = "8ebdc6a292e893ccb0b9f71e8ac27735";
    //2022出行防疫政策的接口地址
    public static String FANGYI_URL = "http://apis.juhe.cn/springTravel/";
    //天气查询接口的KEY值
    public static String WEATHER_KEY = "35448c115752d29249c839f11141bed5";
    //天气查询的接口地址
    public static String WEATHER_URL = "http://apis.juhe.cn/simpleWeather/";
    //星座查询接口的KEY值
    public static String XingZuo_KEY = "b28873a2c371a456eee37e77561389ce";
    //星座查询的接口地址
    public static String XingZuo_URL = "http://web.juhe.cn/constellation/";
}
